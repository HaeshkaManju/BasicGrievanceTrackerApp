from grievance_tracker.application import Application

app = Application()
app.mainloop()